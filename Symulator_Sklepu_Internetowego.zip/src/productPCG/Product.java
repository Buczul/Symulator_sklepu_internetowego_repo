package productPCG;

public interface Product {
    String getId();
    String getTitle();
    double getPrice();
}
